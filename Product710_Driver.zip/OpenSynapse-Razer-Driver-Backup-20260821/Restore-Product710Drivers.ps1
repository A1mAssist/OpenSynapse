$ErrorActionPreference = 'Stop'
$backup = Split-Path -Parent $PSCommandPath
$packages = @(
    'rzcommonu.inf',
    'rzdevu_02c6_dkm.inf',
    'rzdevu_02c6_vcon.inf',
    'rzdevu_02c6_kbd.inf',
    'rzdevu_02c6_mou.inf'
)

foreach ($package in $packages) {
    $path = Join-Path $backup $package
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Missing driver package: $path"
    }

    & pnputil.exe /add-driver $path /install
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to install $package (exit code $LASTEXITCODE)."
    }
}

& pnputil.exe /scan-devices
if ($LASTEXITCODE -ne 0) {
    throw "Device scan failed (exit code $LASTEXITCODE)."
}
